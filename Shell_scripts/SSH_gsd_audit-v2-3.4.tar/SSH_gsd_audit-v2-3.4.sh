#!/bin/ksh

# Date: 16 Apr 2012 - Initial Version
# Author: Kiran K Sanghisetti (kisanghi@in.ibm.com)
#
#
# Purpose: This program is used to perform an audit on SSH against GSD requirements.
# Modified: By Aneel Ramireddy (aneel.ramireddy@in.ibm.com) on 3 Mar 2014
#			Changes:
#				- Flow has changed based on SSH package
#				- Added additional flags to gsdref_description and required_values configuration files
#				- Added functionality for new GSD controls and modified exists control with new changes
#
# Modified: By Aneel Ramireddy (aneel.ramireddy@in.ibm.com) on 01 Jul 2014
#			Changes:
#				- Included code for TEM format		
#
# Modified: By Aneel Ramireddy (aneel.ramireddy@in.ibm.com) on 30 Jul 2014
#			Changes:
#				- Below arguments are optional now
#					* -submitter
#					* -performer
#					* -reference 
#					* -sequence
#				- Updated the required ciphers for Solaris 11,10 and 9	
#
# Modified: By Aneel Ramireddy (aneel.ramireddy@in.ibm.com) on 04 Aug 2014
#			Changes:	
#				- Made -type as optional. By default script will take as 'operate' if -type not passed.
#
# Modified: By Aneel Ramireddy (aneel.ramireddy@in.ibm.com) on 22 Sep 2014
#			Changes:	
#				- Calibrated the script against new GSD 10.5.5.4 tech specs
#				- Added the Linux compatibility 
#
# Modified: By Aneel Ramireddy (aneel.ramireddy@in.ibm.com) on 13 Oct 2014
#			Changes:	
#				- Added the HP-UX compatibility 
#
########################################################################################################

#commands path
if [ -f "/usr/bin/uname" ]; then
	UNAME="/usr/bin/uname"
elif [ -f "/bin/uname" ]; then
	UNAME="/bin/uname"
else
	echo "Error: uname command not found in the defined path"
	exit 1
fi

if [ -f "/usr/bin/pwd" ]; then
	PWD="/usr/bin/pwd"
elif [ -f "/bin/pwd" ]; then
	PWD="/bin/pwd"
else
	echo "Error: pwd command not found in the defined path"
	exit 1
fi

AWK="/usr/bin/awk"
WC="/usr/bin/wc"
CUT="/usr/bin/cut"
BC="/usr/bin/bc"
HEAD="/usr/bin/head"
TAIL="/usr/bin/tail"


AUDIT_HOME=`$PWD`

ECM_OS_NAME_FIELD=$($UNAME  -s)
GRIDHOST="$AUDIT_HOME/GRIDHOST"
if [ "$ECM_OS_NAME_FIELD" = "SunOS" ]; then
	GSDREF_DECR="$AUDIT_HOME/gsdref_description-v1-Solaris.cfg"
	GSD_REQ_VAL="$AUDIT_HOME/required_values-v1-Solaris.cfg"
	IFCONFIG="/usr/sbin/ifconfig"
	CAT="/usr/bin/cat"
	ECHO="/usr/bin/echo"
	GREP="/usr/bin/grep"
	SED="/usr/bin/sed"
elif [ "$ECM_OS_NAME_FIELD" = "Linux" ]; then
	GSDREF_DECR="$AUDIT_HOME/gsdref_description-v1-Linux.cfg"
	GSD_REQ_VAL="$AUDIT_HOME/required_values-v1-Linux.cfg"
	IFCONFIG="/sbin/ifconfig"
	CAT="/bin/cat"
	ECHO="/bin/echo"
	GREP="/bin/grep"
	SED="/bin/sed"
elif [ "$ECM_OS_NAME_FIELD" = "HP-UX" ]; then
	GSDREF_DECR="$AUDIT_HOME/gsdref_description-v1-HP-UX.cfg"
	GSD_REQ_VAL="$AUDIT_HOME/required_values-v1-HP-UX.cfg"
	NETSTAT="/usr/bin/netstat"
	IFCONFIG="/usr/sbin/ifconfig"
	CAT="/usr/bin/cat"
	ECHO="/usr/bin/echo"
	GREP="/usr/bin/grep"
	SED="/usr/bin/sed"
else
	$ECHO "Error: Unable to find the OS type"
	exit 1
fi


HOSTNAME=`$UNAME -n`
DATE=`date "+%m-%d-%Y"`
SSH_VER=""
#AUDIT_HOME="/opt/Tivoli/audit"
if [ -f "/etc/ssh/sshd_config" ]; then
	SSH_CONFIG="/etc/ssh/sshd_config"
elif [ -f "/opt/ssh/etc/sshd_config" ]; then
	SSH_CONFIG="/opt/ssh/etc/sshd_config"
elif [ -f "/usr/local/etc/sshd_config" ]; then
	SSH_CONFIG="/usr/local/etc/sshd_config" 
else
	$ECHO "Error: sshd_config not found"
	exit
fi
OSR_CONF="$AUDIT_HOME/osr_config"
REPORT="$AUDIT_HOME/"$HOSTNAME"_ssh_audit_report_"$DATE".csv"
ECM_OUTPUT_FILE="$AUDIT_HOME/"$HOSTNAME"_ssh_audit_ecm_report_"$DATE".csv"
LOG_FILE="$AUDIT_HOME/ssh_audit_log_"$DATE".LOG"
DESC_DIR="$AUDIT_HOME/descriptions"
TMP_FILE="/tmp/ssh_version_info.tmp"
RESULT=""
REQ_VAL=""
ACT_VAL=""

OSR_USRS="root|daemon|bin|sys|adm|svctag|uucp|nuucp|smmsp|listen|lp|imnadm|sms-svc|nobody|shutsafe|veritas|ivmgr|perfmgr|soeaud|webservd|gdm"
OSR_GRP="root|other|bin|sys|adm|sms|uucp|mail|tty|lp|nuucp|daemon|sysadmin|smmsp|nobody|cimsrvr|imnadm|nobody|shutsafe|veritas|ivmgr"

# TEM Output Variables
ECM_VERSION_FIELD="3"
ECM_SOURCE_FIELD="TEM"
ECM_CUSTOMER_ID_FIELD="100100207"
ECM_CUSTOMER_NAME_FIELD="telstra"
ECM_COUNTRY_FIELD="AUSTRALIA"
ECM_HOSTNAME_FIELD=$HOSTNAME
if [ "$ECM_OS_NAME_FIELD" = "HP-UX" ]; then
	ECM_IP_FIELD=$($NETSTAT  -in | $HEAD -n2 | $TAIL -n1 | $AWK '{ print $3 }')
else
	ECM_IP_FIELD=$($IFCONFIG -a | $GREP inet | $HEAD -2 | $TAIL -1 | $CUT -f2 -d' ')
fi
ECM_OS_VERSION_FIELD=$($UNAME -r)
ECM_SCAN_TYPE_FIELD="O"
ECM_APPLICATION_CATEGORY_FIELD="SSH" 
ECM_APPLICATION_NAME_FIELD="" #BLANK ON PURPOSE
ECM_INSTANCE_NAME_FIELD=""
#ECM_DATE_STAMP="${CURRENT_YEAR}-${CURRENT_MONTH}-${CURRENT_DAY}-${CURRENT_HOURS}.${CURRENT_MINUTES}.${CURRENT_SECONDS}.${CURRENT_NANOSECONDS}"
ECM_DATE_STAMP=`date "+%Y-%m-%d-%H.%M.%S"`."000001"
ECM_RESULT_FIELD="OK"
ECM_POLICY_NAME_FIELD="GSD331"
ECM_POLICY_VERSION_FIELD="10.5.5.4"
if [ "$ECM_OS_NAME_FIELD" = "SunOS" ]; then
	ECM_POLICY_ITEM_FIELD="AB.Solaris_pv10.5.5.4_v2-3.2_20141016"
elif [ "$ECM_OS_NAME_FIELD" = "Linux" ]; then
	ECM_POLICY_ITEM_FIELD="AB.Linux_pv10.5.5.4_v2-3.2_20141016"
elif [ "$ECM_OS_NAME_FIELD" = "HP-UX" ]; then
	ECM_POLICY_ITEM_FIELD="AB.HP-UX_pv10.5.5.4_v2-3.2_20141016"
fi
do_eq_check()
{
 RESULT="Pass"
 ACT_VAL="NULL"
 gsd_ref=$1

 SSH_TAG=`$GREP ${gsd_ref}: $GSD_REQ_VAL | $AWK -F: '{print $2}'`
 REQ_VAL=`$GREP ${gsd_ref}: $GSD_REQ_VAL | $AWK -F: '{print $3}'`
 
 TAG_COUNT=$($GREP "^$SSH_TAG" $SSH_CONFIG | $GREP "^$SSH_TAG " | $WC -l)
	if [ $TAG_COUNT -eq 1 ]
	then
 	     ACT_VAL=`$GREP "^$SSH_TAG" $SSH_CONFIG | $GREP  "^$SSH_TAG " | $AWK '{print $2}'`
		 #echo $SSH_TAG $ACT_VAL
	     [[ "$ACT_VAL" = "$REQ_VAL" ]] || {
			if [ "$ECM_OS_NAME_FIELD" = "Linux" ]; then
				if [ "$SSH_TAG" = "PermitRootLogin" ]; then
					if [ `$CAT $GRIDHOST | $GREP $ECM_HOSTNAME_FIELD | $WC -l` -ne 0 ]; then
						if [ "$ACT_VAL" != "without-password" ]; then
							RESULT="Fail"
							ECM_RESULT_FIELD="KO"
							ECM_SEVERITY_FIELD="Critical"
						fi
					fi
				fi
				if [ "$SSH_TAG" = "PermitUserEnvironment" ]; then
					if [ `$CAT $GRIDHOST | $GREP $ECM_HOSTNAME_FIELD | $WC -l` -ne 0 ]; then
						if [ "$ACT_VAL" != "yes" ]; then
							RESULT="Fail"
							ECM_RESULT_FIELD="KO"
							ECM_SEVERITY_FIELD="Critical"
						fi
					fi
				fi
			else
				RESULT="Fail"
				ECM_RESULT_FIELD="KO"
				ECM_SEVERITY_FIELD="Critical"
			fi
		}
	elif [ $TAG_COUNT -gt 1 ]
	then
		ACT_VAL="Parameter exists multiple times."
	    RESULT="Fail"
		ECM_RESULT_FIELD="KO"
		ECM_SEVERITY_FIELD="Critical"
	else
		ACT_VAL="Parameter does not exists"
	    RESULT="Fail"
		ECM_RESULT_FIELD="KO"
		ECM_SEVERITY_FIELD="Critical"
	fi	

}

do_not_exists_check()
{
	RESULT="Pass"
	ACT_VAL="Not exists"
	gsd_ref=$1

	SSH_TAG=`$GREP ${gsd_ref}: $GSD_REQ_VAL | $AWK -F: '{print $2}'`
	REQ_VAL=`$GREP ${gsd_ref}: $GSD_REQ_VAL | $AWK -F: '{print $3}'`
	 
	TAG_COUNT=`$GREP "^$SSH_TAG" $SSH_CONFIG | $GREP "^$SSH_TAG " | $WC -l`
	if [ $TAG_COUNT -eq 1 ]
	then
 	    ACT_VAL=`$GREP "^$SSH_TAG" $SSH_CONFIG | $GREP "^$SSH_TAG " | $AWK '{print $2}'`
	    RESULT="Fail"
		ECM_RESULT_FIELD="KO"
		ECM_SEVERITY_FIELD="Critical"
	fi	
	#$ECHO "$HOSTNAME,`/usr/bin/cat $DESC_DIR/$GSDREF`,$GSDREF,$GSD_FLAG,$REQ_VAL,$ACT_VAL,$RESULT" 
}

do_le_check()
{
 RESULT="Pass"
 ACT_VAL="NULL"
 gsd_ref=$1

 SSH_TAG=`$GREP ${gsd_ref}: $GSD_REQ_VAL | $AWK -F: '{print $2}'`
 REQ_VAL=`$GREP ${gsd_ref}: $GSD_REQ_VAL | $AWK -F: '{print $3}'`
 
 TAG_COUNT=`$GREP "^$SSH_TAG" $SSH_CONFIG | $GREP  "^$SSH_TAG " | $WC -l`
	if [ $TAG_COUNT -eq 1 ]
	then
		ACT_VAL=`$GREP "^$SSH_TAG" $SSH_CONFIG | $GREP "^$SSH_TAG " | $AWK '{print $2}'`
		if [ "$SSH_TAG" = "MaxStartups" ]; then
			if [ `$ECHO "$ACT_VAL" | $GREP ':' | $WC -l` -ne 0 ]; then  
				ACT_VAL=`$ECHO $ACT_VAL | $AWK -F: '{ print $3 }'`
			fi
		fi			
		if [ "$ACT_VAL" -gt "$REQ_VAL" ]
	     then
		   RESULT="Fail"
		   ECM_RESULT_FIELD="KO"
		   ECM_SEVERITY_FIELD="Critical"
	     fi	
	elif [ $TAG_COUNT -gt 1 ]
	then
		ACT_VAL="Parameter exists multiple times."
	    RESULT="Fail"
		ECM_RESULT_FIELD="KO"
		ECM_SEVERITY_FIELD="Critical"
	else
		ACT_VAL="Parameter does not exists"
	    RESULT="Fail"
		ECM_RESULT_FIELD="KO"
		ECM_SEVERITY_FIELD="Critical"
	fi	

}

do_le_not_check() {
	RESULT="Pass"
	ACT_VAL="NULL"
	gsd_ref=$1
	
	SSH_TAG=`$GREP ${gsd_ref}: $GSD_REQ_VAL | $AWK -F: '{print $2}'`
	REQ_VAL=`$GREP ${gsd_ref}: $GSD_REQ_VAL | $AWK -F: '{print $3}'`
	
	TAG_COUNT=`$GREP "^$SSH_TAG" $SSH_CONFIG | $GREP "^$SSH_TAG " | $WC -l`
	if [ $TAG_COUNT -eq 1 ]
		then
		ACT_VAL=`$GREP "^$SSH_TAG" $SSH_CONFIG | $GREP "^$SSH_TAG " | $AWK '{print $2}'`
		if [ $ACT_VAL -le $REQ_VAL ] && [ $ACT_VAL -ne $2 ]; then
			RESULT="Pass"
		else
			RESULT="Fail"
			ECM_RESULT_FIELD="KO"
			ECM_SEVERITY_FIELD="Critical"
		fi
	elif [ $TAG_COUNT -gt 1 ]
	then
		ACT_VAL="Parameter exists multiple times."
	    RESULT="Fail"
		ECM_RESULT_FIELD="KO"
		ECM_SEVERITY_FIELD="Critical"
	else
		ACT_VAL="Parameter does not exists"
		RESULT="Fail"
		ECM_RESULT_FIELD="KO"
		ECM_SEVERITY_FIELD="Critical"
	fi
}

do_ge_check()
{
 RESULT="Pass"
 ACT_VAL="NULL"
 gsd_ref=$1

 SSH_TAG=`$GREP ${gsd_ref}: $GSD_REQ_VAL | $AWK -F: '{print $2}'`
 REQ_VAL=`$GREP ${gsd_ref}: $GSD_REQ_VAL | $AWK -F: '{print $3}'`
 
 TAG_COUNT=`$GREP "^$SSH_TAG" $SSH_CONFIG | $GREP "^$SSH_TAG " | $WC -l`
	if [ $TAG_COUNT -eq 1 ]
	then
 	     ACT_VAL=`$GREP "^$SSH_TAG" $SSH_CONFIG | $GREP "^$SSH_TAG " | $AWK '{print $2}'`
	     if [ "$ACT_VAL" -lt "$REQ_VAL" ]
	     then
		   RESULT="Fail"
		   ECM_RESULT_FIELD="KO"
		   ECM_SEVERITY_FIELD="Critical"
	     fi	
	elif [ $TAG_COUNT -gt 1 ]
	then
		CT_VAL="Parameter exists multiple times."
	    RESULT="Fail"
		ECM_RESULT_FIELD="KO"
		ECM_SEVERITY_FIELD="Critical"
	else
		ACT_VAL="Parameter does not exists"
	    RESULT="Fail"
		ECM_RESULT_FIELD="KO"
		ECM_SEVERITY_FIELD="Critical"
	fi	

}

Check_ssh_version()
{
	if [ -f /usr/local/bin/ssh ]; then
        SSH="/usr/local/bin/ssh"
    else
        SSH=`which ssh`
    fi
	
	$SSH -V 2> $TMP_FILE
 
	$GREP "Sun_SSH" $TMP_FILE >/dev/null && {
		PKGTYPE="Sun_SSH"
		SSH_VER=$(for i in `$CAT $TMP_FILE`; do $ECHO $i | $AWK '/Sun_SSH_/ {print $0}'; done)
		SSH_VER_COMPLETE=`$ECHO $SSH_VER | sed 's/,//g'`
		print "SSH Version: $SSH_VER" >> $LOG_FILE
		SSH_VER=$($ECHO $SSH_VER | $SED 's/,//' | $AWK -F"_" '{print $3}' | $AWK -F"." '{print $1"."$2}')
		}

	$GREP "OpenSSH" $TMP_FILE >/dev/null && {
		PKGTYPE="OpenSSH"
		SSH_VER=$(for i in `$CAT $TMP_FILE`; do $ECHO $i | $AWK '/OpenSSH/ {print $0}'; done)
		SSH_VER=$($ECHO $SSH_VER | $SED 's/,//' | $AWK -F"_" '{print $2}' | $AWK -F"." '{print $1"."$2}')
		SSH_VER_COMPLETE=`$ECHO $SSH_VER | sed 's/,//g'`
		#$ECHO $SSH_VER_COMPLETE
		print "SSH Version: $SSH_VER" >> $LOG_FILE
		SSH_VER=$($ECHO $SSH_VER | $SED	's/\([0-9]*.[0-9]*\).*/\1/')
		}
}

do_version_spec_chk() {
	RESULT="Pass"
	GSDREF=$1
	REQ_VER=`$ECHO $2 | $AWK -F'-' '{print $1}'`
	OPS=`$ECHO $2 | $AWK -F'-' '{print $2}'`
	REQ_VAL=`$GREP ${GSDREF}: $GSD_REQ_VAL | $AWK -F: '{print $3}'`
	ACT_VAL="N/A"

	if [ "$OPS" = "p" ]; then
		FLAG=`$ECHO "if ( $SSH_VER < $REQ_VER ) 1" | $BC`
	elif [ "$OPS" = "g" ]; then
		FLAG=`$ECHO "if ( $SSH_VER >= $REQ_VER ) 1" | $BC`
	fi

	if [ "$FLAG" -eq 1 ]; then
		OPS=`$GREP ${GSDREF}: $GSD_REQ_VAL | $AWK -F: '{print $4}'`
		if [ "$OPS" = "eq" ]; then 
			do_eq_check $GSDREF
		elif [ "$OPS" = "le" ]; then
			do_le_check $GSDREF
		elif [ "$OPS" = "not" ]; then
			do_not_exists_check $GSDREF
		fi			
	else
		RESULT="Pass"
	fi
}


do_check_AV1213() {
	## AV.1.2.1.3
	GSDREF="AV.1.2.1.3"
	ACT_VAL="NULL"
	REQ_VAL="INFO/DEBUG"
	TAG="LogLevel"
	GSD_FLAG="S"

	TAG_COUNT=`$GREP "^$TAG" $SSH_CONFIG | $GREP "^$TAG " | $WC -l`
	if [ $TAG_COUNT -eq 1 ]
		then
			ACT_VAL=`$GREP "^$TAG" $SSH_CONFIG | $GREP "^$TAG " | $AWK '{print $2}'`
			if [ "$ACT_VAL" = "INFO" ]; then
				RESULT="Pass"
			elif [ "$ACT_VAL" = "DEBUG" ]; then
				OSR="/var/adm/messages"
				RESULT=`ls -ld $OSR | grep -v "^l"| \
					awk '{if ($1!~/[d-][r-][w-][x-][r-][w-][x-][r-]-[x-]/ || $3!~/'$OSR_USRS'/ || $4!~/'$OSR_GRP'/) {
						 print "Fail - log file should be access by root or sysadmin only";
						} else {
							print "Pass";
							}
				}'`
			else
				RESULT="Fail"
			fi
	else
		ACT_VAL="Parameter does not exists"
		RESULT="Fail"
	fi
	GSD_DESC="Determines the level of logging."
	print "$HOSTNAME,$GSD_DESC,$GSDREF,$GSD_FLAG,$REQ_VAL,$ACT_VAL(Installed SSH version: $SSH_VER_COMPLETE),$RESULT" >> $REPORT
	if [ $(echo $RESULT | grep "Fail" | wc -l ) -ne 0 ]; then
		ECM_RESULT_FIELD="KO"
		ECM_SEVERITY_FIELD="Critical"
		print "\"${ECM_VERSION_FIELD}\",\"${ECM_SOURCE_FIELD}\",\"${ECM_CUSTOMER_ID_FIELD}\",\"${ECM_CUSTOMER_NAME_FIELD}\",\"${ECM_COUNTRY_FIELD}\",\"${ECM_HOSTNAME_FIELD}\",\"${ECM_IP_FIELD}\",\"${ECM_OS_NAME_FIELD}\",\"${ECM_OS_VERSION_FIELD}\",\"${ECM_SCAN_TYPE_FIELD}\",\"${ECM_APPLICATION_CATEGORY_FIELD}\",\"${ECM_APPLICATION_NAME_FIELD}\",\"${ECM_INSTANCE_NAME_FIELD}\",\"${ECM_DATE_STAMP}\",\"${ECM_POLICY_NAME_FIELD}\",\"${ECM_POLICY_VERSION_FIELD}\",\"${ECM_POLICY_ITEM_FIELD}\",\"${ECM_RESULT_FIELD}\",\"${ECM_SEVERITY_FIELD}\",\"${GSDREF}\",\"${GSD_DESC}\",\"${REQ_VAL}\",\"${ACT_VAL}\",\"${ECM_SUBMITTER_FIELD}\",\"${ECM_PERFORMER_FIELD}\",\"${ECM_EXTERNAL_REF_FIELD}\",\"${ECM_EXTERNAL_SEQ_FIELD}\"" >> "${ECM_OUTPUT_FILE}"
	fi
}

do_check_AV1212() {
	## AV.1.2.1.2
	GSDREF="AV.1.2.1.2"
	ACT_VAL="NULL"
	REQ_VAL="INFO/DEBUG"
	TAG="LogLevel"
	GSD_FLAG="S"

	TAG_COUNT=`$GREP "^$TAG" $SSH_CONFIG | $GREP "^$TAG " | $WC -l`
	if [ $TAG_COUNT -eq 1 ]
		then
			ACT_VAL=`$GREP "^$TAG" $SSH_CONFIG | $GREP "^$TAG " | $AWK '{print $2}'`
			if [ "$ACT_VAL" = "INFO" ] || [ "$ACT_VAL" = "DEBUG" ]; then
				RESULT="Pass"
			else
				RESULT="Fail"
			fi
	else
		ACT_VAL="Parameter does not exists"
		RESULT="Fail"
	fi
	GSD_DESC="Determines the level of logging."
	print "$HOSTNAME,$GSD_DESC,$GSDREF,$GSD_FLAG,$REQ_VAL,$ACT_VAL(Installed SSH version: $SSH_VER_COMPLETE),$RESULT" >> $REPORT
	if [ $(echo $RESULT | grep "Fail" | wc -l ) -ne 0 ]; then
		ECM_RESULT_FIELD="KO"
		ECM_SEVERITY_FIELD="Critical"
		print "\"${ECM_VERSION_FIELD}\",\"${ECM_SOURCE_FIELD}\",\"${ECM_CUSTOMER_ID_FIELD}\",\"${ECM_CUSTOMER_NAME_FIELD}\",\"${ECM_COUNTRY_FIELD}\",\"${ECM_HOSTNAME_FIELD}\",\"${ECM_IP_FIELD}\",\"${ECM_OS_NAME_FIELD}\",\"${ECM_OS_VERSION_FIELD}\",\"${ECM_SCAN_TYPE_FIELD}\",\"${ECM_APPLICATION_CATEGORY_FIELD}\",\"${ECM_APPLICATION_NAME_FIELD}\",\"${ECM_INSTANCE_NAME_FIELD}\",\"${ECM_DATE_STAMP}\",\"${ECM_POLICY_NAME_FIELD}\",\"${ECM_POLICY_VERSION_FIELD}\",\"${ECM_POLICY_ITEM_FIELD}\",\"${ECM_RESULT_FIELD}\",\"${ECM_SEVERITY_FIELD}\",\"${GSDREF}\",\"${GSD_DESC}\",\"${REQ_VAL}\",\"${ACT_VAL}\",\"${ECM_SUBMITTER_FIELD}\",\"${ECM_PERFORMER_FIELD}\",\"${ECM_EXTERNAL_REF_FIELD}\",\"${ECM_EXTERNAL_SEQ_FIELD}\"" >> "${ECM_OUTPUT_FILE}"
	fi
}

do_check_AV623() {
	GSDREF="AV.6.2.3"
	ACT_VAL="UNKNOWN"
	RESULT="Pass"
	TAG="Ciphers"
	GSD_FLAG="B"
	
	if [ "$PCI" = "0" ]; then
				RESULT="Pass"
				ACT_VAL="PCI Class requirement - Not Applicable"
				GSD_DESC=`$CAT $DESC_DIR/$GSDREF`
				print "$HOSTNAME,$GSD_DESC,$GSDREF,$GSD_FLAG,\"$REQ_VAL\",\"$ACT_VAL\",$RESULT" >> $REPORT
	else
		TAG_COUNT=`$GREP "^$TAG" $SSH_CONFIG | $GREP "^$TAG " | $WC -l`
		if [ $TAG_COUNT -eq 1 ]
			then
			ACT_VAL=`$GREP "^$TAG" $SSH_CONFIG | $GREP "^$TAG " | $AWK '{print $2}'`
			if [ "$ECM_OS_VERSION_FIELD" = "5.9" ]; then
				REQ_VAL="aes128-ctr"
				if [ "$REQ_VAL" != "$ACT_VAL" ]; then
					RESULT="Fail"
					ECM_RESULT_FIELD="KO"
					ECM_SEVERITY_FIELD="Critical"
					print "\"${ECM_VERSION_FIELD}\",\"${ECM_SOURCE_FIELD}\",\"${ECM_CUSTOMER_ID_FIELD}\",\"${ECM_CUSTOMER_NAME_FIELD}\",\"${ECM_COUNTRY_FIELD}\",\"${ECM_HOSTNAME_FIELD}\",\"${ECM_IP_FIELD}\",\"${ECM_OS_NAME_FIELD}\",\"${ECM_OS_VERSION_FIELD}\",\"${ECM_SCAN_TYPE_FIELD}\",\"${ECM_APPLICATION_CATEGORY_FIELD}\",\"${ECM_APPLICATION_NAME_FIELD}\",\"${ECM_INSTANCE_NAME_FIELD}\",\"${ECM_DATE_STAMP}\",\"${ECM_POLICY_NAME_FIELD}\",\"${ECM_POLICY_VERSION_FIELD}\",\"${ECM_POLICY_ITEM_FIELD}\",\"${ECM_RESULT_FIELD}\",\"${ECM_SEVERITY_FIELD}\",\"${GSDREF}\",\"${GSD_DESC}\",\"${REQ_VAL}\",\"${ACT_VAL}\",\"${ECM_SUBMITTER_FIELD}\",\"${ECM_PERFORMER_FIELD}\",\"${ECM_EXTERNAL_REF_FIELD}\",\"${ECM_EXTERNAL_SEQ_FIELD}\"" >> "${ECM_OUTPUT_FILE}"
				fi
			elif [ "$ECM_OS_VERSION_FIELD" = "5.10" ] || [ "$ECM_OS_VERSION_FIELD" = "5.11" ];then
				REQ_VAL="aes128-ctr,aes192-ctr,aes256-ctr"
				ACT_VAL1=`echo $ACT_VAL | tr ',' '\n' |  sort | tr '\n' ','`
				ACT_VAL1=`echo $ACT_VAL1| sed 's/,$//'`
				echo $REQ_VAL
				echo $ACT_VAL
				echo $ACT_VAL1
				if [ "$REQ_VAL" != "$ACT_VAL1" ]; then
					RESULT="Fail"
					ECM_RESULT_FIELD="KO"
					ECM_SEVERITY_FIELD="Critical"
					print "\"${ECM_VERSION_FIELD}\",\"${ECM_SOURCE_FIELD}\",\"${ECM_CUSTOMER_ID_FIELD}\",\"${ECM_CUSTOMER_NAME_FIELD}\",\"${ECM_COUNTRY_FIELD}\",\"${ECM_HOSTNAME_FIELD}\",\"${ECM_IP_FIELD}\",\"${ECM_OS_NAME_FIELD}\",\"${ECM_OS_VERSION_FIELD}\",\"${ECM_SCAN_TYPE_FIELD}\",\"${ECM_APPLICATION_CATEGORY_FIELD}\",\"${ECM_APPLICATION_NAME_FIELD}\",\"${ECM_INSTANCE_NAME_FIELD}\",\"${ECM_DATE_STAMP}\",\"${ECM_POLICY_NAME_FIELD}\",\"${ECM_POLICY_VERSION_FIELD}\",\"${ECM_POLICY_ITEM_FIELD}\",\"${ECM_RESULT_FIELD}\",\"${ECM_SEVERITY_FIELD}\",\"${GSDREF}\",\"${GSD_DESC}\",\"${REQ_VAL}\",\"${ACT_VAL}\",\"${ECM_SUBMITTER_FIELD}\",\"${ECM_PERFORMER_FIELD}\",\"${ECM_EXTERNAL_REF_FIELD}\",\"${ECM_EXTERNAL_SEQ_FIELD}\"" >> "${ECM_OUTPUT_FILE}"
				fi
			fi
		else
			ACT_VAL="Parameter does not exists"	 
			RESULT="Fail"
			ECM_RESULT_FIELD="KO"
			ECM_SEVERITY_FIELD="Critical"
			print "\"${ECM_VERSION_FIELD}\",\"${ECM_SOURCE_FIELD}\",\"${ECM_CUSTOMER_ID_FIELD}\",\"${ECM_CUSTOMER_NAME_FIELD}\",\"${ECM_COUNTRY_FIELD}\",\"${ECM_HOSTNAME_FIELD}\",\"${ECM_IP_FIELD}\",\"${ECM_OS_NAME_FIELD}\",\"${ECM_OS_VERSION_FIELD}\",\"${ECM_SCAN_TYPE_FIELD}\",\"${ECM_APPLICATION_CATEGORY_FIELD}\",\"${ECM_APPLICATION_NAME_FIELD}\",\"${ECM_INSTANCE_NAME_FIELD}\",\"${ECM_DATE_STAMP}\",\"${ECM_POLICY_NAME_FIELD}\",\"${ECM_POLICY_VERSION_FIELD}\",\"${ECM_POLICY_ITEM_FIELD}\",\"${ECM_RESULT_FIELD}\",\"${ECM_SEVERITY_FIELD}\",\"${GSDREF}\",\"${GSD_DESC}\",\"${REQ_VAL}\",\"${ACT_VAL}\",\"${ECM_SUBMITTER_FIELD}\",\"${ECM_PERFORMER_FIELD}\",\"${ECM_EXTERNAL_REF_FIELD}\",\"${ECM_EXTERNAL_SEQ_FIELD}\"" >> "${ECM_OUTPUT_FILE}"
		fi
		GSD_DESC=`$CAT $DESC_DIR/$GSDREF`
		print "$HOSTNAME,$GSD_DESC,$GSDREF,$GSD_FLAG,\"$REQ_VAL\",\"$ACT_VAL\"(Installed SSH version: $SSH_VER_COMPLETE),$RESULT" >> $REPORT
	fi
}

do_check_AV2111() {
	GSDREF="AV.2.1.1.1"
	ACT_VAL="NULL"
	REQ_VAL="2"
	TAG="Protocol"
	RESULT="Pass"
	GSD_FLAG="B"

	TAG_COUNT=`$GREP "^$TAG" $SSH_CONFIG | $GREP "^$TAG " | $WC -l`
	if [ $TAG_COUNT -eq 1 ]
		then
		ACT_VAL=`$GREP "^$TAG" $SSH_CONFIG | $GREP "^$TAG " | $AWK '{print $2}'`
		SSH_PROT=`$ECHO $ACT_VAL | $GREP 1 | $WC -l`
		if [ $SSH_PROT -eq 1 ]; then
			RESULT="Fail"
		else
			RESULT="Pass"
		fi
	else
		ACT_VAL="Parameter does not exists"
		RESULT="Fail"
	fi
	GSD_DESC="Disallow the use of SSH version 1"
	print "$HOSTNAME,$GSD_DESC,$GSDREF,$GSD_FLAG,$REQ_VAL,$ACT_VAL(Installed SSH version: $SSH_VER_COMPLETE),$RESULT" >> $REPORT
	if [ "$RESULT" = "Fail" ]; then
		ECM_RESULT_FIELD="KO"
		ECM_SEVERITY_FIELD="Critical"
		print "\"${ECM_VERSION_FIELD}\",\"${ECM_SOURCE_FIELD}\",\"${ECM_CUSTOMER_ID_FIELD}\",\"${ECM_CUSTOMER_NAME_FIELD}\",\"${ECM_COUNTRY_FIELD}\",\"${ECM_HOSTNAME_FIELD}\",\"${ECM_IP_FIELD}\",\"${ECM_OS_NAME_FIELD}\",\"${ECM_OS_VERSION_FIELD}\",\"${ECM_SCAN_TYPE_FIELD}\",\"${ECM_APPLICATION_CATEGORY_FIELD}\",\"${ECM_APPLICATION_NAME_FIELD}\",\"${ECM_INSTANCE_NAME_FIELD}\",\"${ECM_DATE_STAMP}\",\"${ECM_POLICY_NAME_FIELD}\",\"${ECM_POLICY_VERSION_FIELD}\",\"${ECM_POLICY_ITEM_FIELD}\",\"${ECM_RESULT_FIELD}\",\"${ECM_SEVERITY_FIELD}\",\"${GSDREF}\",\"${GSD_DESC}\",\"${REQ_VAL}\",\"${ACT_VAL}\",\"${ECM_SUBMITTER_FIELD}\",\"${ECM_PERFORMER_FIELD}\",\"${ECM_EXTERNAL_REF_FIELD}\",\"${ECM_EXTERNAL_SEQ_FIELD}\"" >> "${ECM_OUTPUT_FILE}"
	fi
}

do_check_AV2113() {
	GSDREF="AV.2.1.1.3"
	ACT_VAL="NULL"
	REQ_VAL="The DES algorithm uses 56-bit keys and is relatively easy to compromise. Therefore it must not be used."
	TAG="Ciphers"
	RESULT="Pass"
	GSD_FLAG="B"

	TAG_COUNT=`$GREP "^$TAG" $SSH_CONFIG | $GREP "^$TAG " | $WC -l`
	if [ $TAG_COUNT -eq 1 ]
		then
		ACT_VAL=`$GREP "^$TAG" $SSH_CONFIG | $GREP "^$TAG " | $AWK '{print $2}'`
		if [ `$ECHO $ACT_VAL | $GREP -v "3DES" | $GREP 'DES' | $WC -l` -ne 0 ]; then
			RESULT="Fail"
		else
			RESULT="Pass"
		fi
	else
		ACT_VAL="Parameter does not exists"
		RESULT="Fail"
	fi
	GSD_DESC="Data Transmission - DES algorithm"
	print "$HOSTNAME,$GSD_DESC,$GSDREF,$GSD_FLAG,$REQ_VAL,\"$ACT_VAL(Installed SSH version: $SSH_VER_COMPLETE)\",$RESULT" >> $REPORT
	if [ "$RESULT" = "Fail" ]; then
		ECM_RESULT_FIELD="KO"
		ECM_SEVERITY_FIELD="Critical"
		print "\"${ECM_VERSION_FIELD}\",\"${ECM_SOURCE_FIELD}\",\"${ECM_CUSTOMER_ID_FIELD}\",\"${ECM_CUSTOMER_NAME_FIELD}\",\"${ECM_COUNTRY_FIELD}\",\"${ECM_HOSTNAME_FIELD}\",\"${ECM_IP_FIELD}\",\"${ECM_OS_NAME_FIELD}\",\"${ECM_OS_VERSION_FIELD}\",\"${ECM_SCAN_TYPE_FIELD}\",\"${ECM_APPLICATION_CATEGORY_FIELD}\",\"${ECM_APPLICATION_NAME_FIELD}\",\"${ECM_INSTANCE_NAME_FIELD}\",\"${ECM_DATE_STAMP}\",\"${ECM_POLICY_NAME_FIELD}\",\"${ECM_POLICY_VERSION_FIELD}\",\"${ECM_POLICY_ITEM_FIELD}\",\"${ECM_RESULT_FIELD}\",\"${ECM_SEVERITY_FIELD}\",\"${GSDREF}\",\"${GSD_DESC}\",\"${REQ_VAL}\",\"${ACT_VAL}\",\"${ECM_SUBMITTER_FIELD}\",\"${ECM_PERFORMER_FIELD}\",\"${ECM_EXTERNAL_REF_FIELD}\",\"${ECM_EXTERNAL_SEQ_FIELD}\"" >> "${ECM_OUTPUT_FILE}"
	fi
}
do_check_AV501() {
	GSDREF="AV.5.0.1"
	ACT_VAL="sshd is not member of any other group"
	REQ_VAL="Not to be set"
	RESULT="Pass"
	GSD_FLAG="B"
	GSD_DESC="The user ID used for privilege separation "
	if [ `$GREP sshd /etc/group | $GREP -c -v ^sshd` -ne 0 ]; then
		RESULT="Fail"
		ACT_VAL="sshd is member of group(s) other than sshd"
		ECM_RESULT_FIELD="KO"
		ECM_SEVERITY_FIELD="Critical"
		print "\"${ECM_VERSION_FIELD}\",\"${ECM_SOURCE_FIELD}\",\"${ECM_CUSTOMER_ID_FIELD}\",\"${ECM_CUSTOMER_NAME_FIELD}\",\"${ECM_COUNTRY_FIELD}\",\"${ECM_HOSTNAME_FIELD}\",\"${ECM_IP_FIELD}\",\"${ECM_OS_NAME_FIELD}\",\"${ECM_OS_VERSION_FIELD}\",\"${ECM_SCAN_TYPE_FIELD}\",\"${ECM_APPLICATION_CATEGORY_FIELD}\",\"${ECM_APPLICATION_NAME_FIELD}\",\"${ECM_INSTANCE_NAME_FIELD}\",\"${ECM_DATE_STAMP}\",\"${ECM_POLICY_NAME_FIELD}\",\"${ECM_POLICY_VERSION_FIELD}\",\"${ECM_POLICY_ITEM_FIELD}\",\"${ECM_RESULT_FIELD}\",\"${ECM_SEVERITY_FIELD}\",\"${GSDREF}\",\"${GSD_DESC}\",\"${REQ_VAL}\",\"${ACT_VAL}\",\"${ECM_SUBMITTER_FIELD}\",\"${ECM_PERFORMER_FIELD}\",\"${ECM_EXTERNAL_REF_FIELD}\",\"${ECM_EXTERNAL_SEQ_FIELD}\"" >> "${ECM_OUTPUT_FILE}"
	fi
	print "$HOSTNAME,$GSD_DESC,$GSDREF,$GSD_FLAG,$REQ_VAL,$ACT_VAL(Installed SSH version: $SSH_VER_COMPLETE),$RESULT" >> $REPORT
}

do_check_AV1732_AV1733 () {
	TAG="HostbasedAuthentication"
	REQ_VAL="no"
	TAG_COUNT=`$GREP "^$TAG" $SSH_CONFIG | $GREP "^$TAG " | $WC -l`
	
	if [ $TAG_COUNT -eq 1 ]
	then
		ACT_VAL=`$GREP "^$TAG" $SSH_CONFIG | $GREP "^$TAG " | $AWK '{print $2}'`
		[[ "$ACT_VAL" = "$REQ_VAL" ]] && {
			GSDREF="AV.1.7.3.2"
			ACT_VAL="HostbasedAuthentication is set to no"
			REQ_VAL="HostbasedAuthentication should set to no"
			RESULT="Pass"
			GSD_FLAG="B"
			GSD_DESC="Host-Based Authentication /etc/hosts.equiv file"
			print "$HOSTNAME,$GSD_DESC,$GSDREF,$GSD_FLAG,$REQ_VAL,$ACT_VAL(Installed SSH version: $SSH_VER_COMPLETE),$RESULT" >> $REPORT
			
			GSDREF="AV.1.7.3.3"
			GSD_DESC="Host-Based Authentication /etc/shosts.equiv file"
			print "$HOSTNAME,$GSD_DESC,$GSDREF,$GSD_FLAG,$REQ_VAL,$ACT_VAL(Installed SSH version: $SSH_VER_COMPLETE),$RESULT" >> $REPORT
		
		} || {
			RESULT="Fail"
			ECM_RESULT_FIELD="KO"
			ECM_SEVERITY_FIELD="Critical"
			ACT_VAL="HostbasedAuthentication is set to yes"
			REQ_VAL="HostbasedAuthentication should set to no"
			GSD_FLAG="B"
			
			GSDREF="AV.1.7.3.2"
			GSD_DESC="Host-Based Authentication /etc/hosts.equiv file"
			print "\"${ECM_VERSION_FIELD}\",\"${ECM_SOURCE_FIELD}\",\"${ECM_CUSTOMER_ID_FIELD}\",\"${ECM_CUSTOMER_NAME_FIELD}\",\"${ECM_COUNTRY_FIELD}\",\"${ECM_HOSTNAME_FIELD}\",\"${ECM_IP_FIELD}\",\"${ECM_OS_NAME_FIELD}\",\"${ECM_OS_VERSION_FIELD}\",\"${ECM_SCAN_TYPE_FIELD}\",\"${ECM_APPLICATION_CATEGORY_FIELD}\",\"${ECM_APPLICATION_NAME_FIELD}\",\"${ECM_INSTANCE_NAME_FIELD}\",\"${ECM_DATE_STAMP}\",\"${ECM_POLICY_NAME_FIELD}\",\"${ECM_POLICY_VERSION_FIELD}\",\"${ECM_POLICY_ITEM_FIELD}\",\"${ECM_RESULT_FIELD}\",\"${ECM_SEVERITY_FIELD}\",\"${GSDREF}\",\"${GSD_DESC}\",\"${REQ_VAL}\",\"${ACT_VAL}\",\"${ECM_SUBMITTER_FIELD}\",\"${ECM_PERFORMER_FIELD}\",\"${ECM_EXTERNAL_REF_FIELD}\",\"${ECM_EXTERNAL_SEQ_FIELD}\"" >> "${ECM_OUTPUT_FILE}"
			print "$HOSTNAME,$GSD_DESC,$GSDREF,$GSD_FLAG,$REQ_VAL,$ACT_VAL(Installed SSH version: $SSH_VER_COMPLETE),$RESULT" >> $REPORT
			
			GSDREF="AV.1.7.3.3"
			GSD_DESC="Host-Based Authentication /etc/shosts.equiv file"
			print "\"${ECM_VERSION_FIELD}\",\"${ECM_SOURCE_FIELD}\",\"${ECM_CUSTOMER_ID_FIELD}\",\"${ECM_CUSTOMER_NAME_FIELD}\",\"${ECM_COUNTRY_FIELD}\",\"${ECM_HOSTNAME_FIELD}\",\"${ECM_IP_FIELD}\",\"${ECM_OS_NAME_FIELD}\",\"${ECM_OS_VERSION_FIELD}\",\"${ECM_SCAN_TYPE_FIELD}\",\"${ECM_APPLICATION_CATEGORY_FIELD}\",\"${ECM_APPLICATION_NAME_FIELD}\",\"${ECM_INSTANCE_NAME_FIELD}\",\"${ECM_DATE_STAMP}\",\"${ECM_POLICY_NAME_FIELD}\",\"${ECM_POLICY_VERSION_FIELD}\",\"${ECM_POLICY_ITEM_FIELD}\",\"${ECM_RESULT_FIELD}\",\"${ECM_SEVERITY_FIELD}\",\"${GSDREF}\",\"${GSD_DESC}\",\"${REQ_VAL}\",\"${ACT_VAL}\",\"${ECM_SUBMITTER_FIELD}\",\"${ECM_PERFORMER_FIELD}\",\"${ECM_EXTERNAL_REF_FIELD}\",\"${ECM_EXTERNAL_SEQ_FIELD}\"" >> "${ECM_OUTPUT_FILE}"
			print "$HOSTNAME,$GSD_DESC,$GSDREF,$GSD_FLAG,$REQ_VAL,$ACT_VAL(Installed SSH version: $SSH_VER_COMPLETE),$RESULT" >> $REPORT
		}
	else
		ACT_VAL="Parameter does not exists"
		RESULT="Fail"
		ECM_RESULT_FIELD="KO"
		ECM_SEVERITY_FIELD="Critical"
		REQ_VAL="HostbasedAuthentication should set to no"
		GSD_FLAG="B"
		
		GSDREF="AV.1.7.3.2"
		GSD_DESC="Host-Based Authentication /etc/hosts.equiv file"
		print "\"${ECM_VERSION_FIELD}\",\"${ECM_SOURCE_FIELD}\",\"${ECM_CUSTOMER_ID_FIELD}\",\"${ECM_CUSTOMER_NAME_FIELD}\",\"${ECM_COUNTRY_FIELD}\",\"${ECM_HOSTNAME_FIELD}\",\"${ECM_IP_FIELD}\",\"${ECM_OS_NAME_FIELD}\",\"${ECM_OS_VERSION_FIELD}\",\"${ECM_SCAN_TYPE_FIELD}\",\"${ECM_APPLICATION_CATEGORY_FIELD}\",\"${ECM_APPLICATION_NAME_FIELD}\",\"${ECM_INSTANCE_NAME_FIELD}\",\"${ECM_DATE_STAMP}\",\"${ECM_POLICY_NAME_FIELD}\",\"${ECM_POLICY_VERSION_FIELD}\",\"${ECM_POLICY_ITEM_FIELD}\",\"${ECM_RESULT_FIELD}\",\"${ECM_SEVERITY_FIELD}\",\"${GSDREF}\",\"${GSD_DESC}\",\"${REQ_VAL}\",\"${ACT_VAL}\",\"${ECM_SUBMITTER_FIELD}\",\"${ECM_PERFORMER_FIELD}\",\"${ECM_EXTERNAL_REF_FIELD}\",\"${ECM_EXTERNAL_SEQ_FIELD}\"" >> "${ECM_OUTPUT_FILE}"
		print "$HOSTNAME,$GSD_DESC,$GSDREF,$GSD_FLAG,$REQ_VAL,$ACT_VAL(Installed SSH version: $SSH_VER_COMPLETE),$RESULT" >> $REPORT
		
		GSDREF="AV.1.7.3.3"
		GSD_DESC="Host-Based Authentication /etc/shosts.equiv file"
		print "\"${ECM_VERSION_FIELD}\",\"${ECM_SOURCE_FIELD}\",\"${ECM_CUSTOMER_ID_FIELD}\",\"${ECM_CUSTOMER_NAME_FIELD}\",\"${ECM_COUNTRY_FIELD}\",\"${ECM_HOSTNAME_FIELD}\",\"${ECM_IP_FIELD}\",\"${ECM_OS_NAME_FIELD}\",\"${ECM_OS_VERSION_FIELD}\",\"${ECM_SCAN_TYPE_FIELD}\",\"${ECM_APPLICATION_CATEGORY_FIELD}\",\"${ECM_APPLICATION_NAME_FIELD}\",\"${ECM_INSTANCE_NAME_FIELD}\",\"${ECM_DATE_STAMP}\",\"${ECM_POLICY_NAME_FIELD}\",\"${ECM_POLICY_VERSION_FIELD}\",\"${ECM_POLICY_ITEM_FIELD}\",\"${ECM_RESULT_FIELD}\",\"${ECM_SEVERITY_FIELD}\",\"${GSDREF}\",\"${GSD_DESC}\",\"${REQ_VAL}\",\"${ACT_VAL}\",\"${ECM_SUBMITTER_FIELD}\",\"${ECM_PERFORMER_FIELD}\",\"${ECM_EXTERNAL_REF_FIELD}\",\"${ECM_EXTERNAL_SEQ_FIELD}\"" >> "${ECM_OUTPUT_FILE}"
		print "$HOSTNAME,$GSD_DESC,$GSDREF,$GSD_FLAG,$REQ_VAL,$ACT_VAL(Installed SSH version: $SSH_VER_COMPLETE),$RESULT" >> $REPORT
	fi	
}

do_check_AV602() {
	GSDREF="AV.6.0.2"
	ACT_VAL="NULL"
	REQ_VAL="2"
	TAG="Protocol"
	RESULT="Pass"
	GSD_FLAG="S"

	TAG_COUNT=`$GREP "^$TAG" $SSH_CONFIG | $GREP "^$TAG " | $WC -l`
	if [ $TAG_COUNT -eq 1 ]
		then
		ACT_VAL=`$GREP "^$TAG" $SSH_CONFIG | $GREP "^$TAG " | $AWK '{print $2}'`
		SSH_PROT=`$ECHO $ACT_VAL | $GREP 1 | $WC -l`
		if [ $SSH_PROT -eq 1 ]; then
			RESULT="Fail"
		else
			RESULT="Pass"
		fi
	else
		ACT_VAL="Parameter does not exists"
		RESULT="Fail"
	fi
	GSD_DESC="Disallow the use of SSH version 1"
	print "$HOSTNAME,$GSD_DESC,$GSDREF,$GSD_FLAG,$REQ_VAL,$ACT_VAL(Installed SSH version: $SSH_VER_COMPLETE),$RESULT" >> $REPORT
	if [ "$RESULT" = "Fail" ]; then
		ECM_RESULT_FIELD="KO"
		ECM_SEVERITY_FIELD="Critical"
		print "\"${ECM_VERSION_FIELD}\",\"${ECM_SOURCE_FIELD}\",\"${ECM_CUSTOMER_ID_FIELD}\",\"${ECM_CUSTOMER_NAME_FIELD}\",\"${ECM_COUNTRY_FIELD}\",\"${ECM_HOSTNAME_FIELD}\",\"${ECM_IP_FIELD}\",\"${ECM_OS_NAME_FIELD}\",\"${ECM_OS_VERSION_FIELD}\",\"${ECM_SCAN_TYPE_FIELD}\",\"${ECM_APPLICATION_CATEGORY_FIELD}\",\"${ECM_APPLICATION_NAME_FIELD}\",\"${ECM_INSTANCE_NAME_FIELD}\",\"${ECM_DATE_STAMP}\",\"${ECM_POLICY_NAME_FIELD}\",\"${ECM_POLICY_VERSION_FIELD}\",\"${ECM_POLICY_ITEM_FIELD}\",\"${ECM_RESULT_FIELD}\",\"${ECM_SEVERITY_FIELD}\",\"${GSDREF}\",\"${GSD_DESC}\",\"${REQ_VAL}\",\"${ACT_VAL}\",\"${ECM_SUBMITTER_FIELD}\",\"${ECM_PERFORMER_FIELD}\",\"${ECM_EXTERNAL_REF_FIELD}\",\"${ECM_EXTERNAL_SEQ_FIELD}\"" >> "${ECM_OUTPUT_FILE}"
	fi
}

do_check_AV6014() {
	GSDREF="AV.6.0.14"
	ACT_VAL="UNKNOWN"
	REQ_VAL="aes128-ctr aes192-ctr aes256-ctr or 3DES"
	RESULT="Pass"
	TAG="Ciphers"
	GSD_FLAG="B"
	GSD_DESC=`$CAT $DESC_DIR/$GSDREF`
	
	if [ "$OS" = "SuSE11" ]  || [ "$OS" = "RedHat6" ]; then
		TAG_COUNT=`$GREP "^$TAG" $SSH_CONFIG | $GREP "^$TAG " | $WC -l`
		if [ $TAG_COUNT -eq 1 ]
			then
			ACT_VAL=`$GREP "^$TAG" $SSH_CONFIG | $GREP "^$TAG " | $AWK '{print $2}'`
			
			for CIPHER in `echo $ACT_VAL | tr ',' '\n' |  sort | tr '\n' ','`
			do
				if [ `$ECHO $REQ_VAL | $GREP "$ACT_VAL1" | $WC -l` -eq 0 ]; then
					RESULT="Fail"
				fi
			done
			if [ "$RESULT" = "Fail" ]; then
					ECM_RESULT_FIELD="KO"
					ECM_SEVERITY_FIELD="Critical"
					print "\"${ECM_VERSION_FIELD}\",\"${ECM_SOURCE_FIELD}\",\"${ECM_CUSTOMER_ID_FIELD}\",\"${ECM_CUSTOMER_NAME_FIELD}\",\"${ECM_COUNTRY_FIELD}\",\"${ECM_HOSTNAME_FIELD}\",\"${ECM_IP_FIELD}\",\"${ECM_OS_NAME_FIELD}\",\"${ECM_OS_VERSION_FIELD}\",\"${ECM_SCAN_TYPE_FIELD}\",\"${ECM_APPLICATION_CATEGORY_FIELD}\",\"${ECM_APPLICATION_NAME_FIELD}\",\"${ECM_INSTANCE_NAME_FIELD}\",\"${ECM_DATE_STAMP}\",\"${ECM_POLICY_NAME_FIELD}\",\"${ECM_POLICY_VERSION_FIELD}\",\"${ECM_POLICY_ITEM_FIELD}\",\"${ECM_RESULT_FIELD}\",\"${ECM_SEVERITY_FIELD}\",\"${GSDREF}\",\"${GSD_DESC}\",\"${REQ_VAL}\",\"${ACT_VAL}\",\"${ECM_SUBMITTER_FIELD}\",\"${ECM_PERFORMER_FIELD}\",\"${ECM_EXTERNAL_REF_FIELD}\",\"${ECM_EXTERNAL_SEQ_FIELD}\"" >> "${ECM_OUTPUT_FILE}"
				fi
		else
			ACT_VAL="Parameter does not exists"	 
			RESULT="Fail"
			ECM_RESULT_FIELD="KO"
			ECM_SEVERITY_FIELD="Critical"
			print "\"${ECM_VERSION_FIELD}\",\"${ECM_SOURCE_FIELD}\",\"${ECM_CUSTOMER_ID_FIELD}\",\"${ECM_CUSTOMER_NAME_FIELD}\",\"${ECM_COUNTRY_FIELD}\",\"${ECM_HOSTNAME_FIELD}\",\"${ECM_IP_FIELD}\",\"${ECM_OS_NAME_FIELD}\",\"${ECM_OS_VERSION_FIELD}\",\"${ECM_SCAN_TYPE_FIELD}\",\"${ECM_APPLICATION_CATEGORY_FIELD}\",\"${ECM_APPLICATION_NAME_FIELD}\",\"${ECM_INSTANCE_NAME_FIELD}\",\"${ECM_DATE_STAMP}\",\"${ECM_POLICY_NAME_FIELD}\",\"${ECM_POLICY_VERSION_FIELD}\",\"${ECM_POLICY_ITEM_FIELD}\",\"${ECM_RESULT_FIELD}\",\"${ECM_SEVERITY_FIELD}\",\"${GSDREF}\",\"${GSD_DESC}\",\"${REQ_VAL}\",\"${ACT_VAL}\",\"${ECM_SUBMITTER_FIELD}\",\"${ECM_PERFORMER_FIELD}\",\"${ECM_EXTERNAL_REF_FIELD}\",\"${ECM_EXTERNAL_SEQ_FIELD}\"" >> "${ECM_OUTPUT_FILE}"
		fi
	else
		ACT_VAL="N/A"		
		print "$HOSTNAME,$GSD_DESC,$GSDREF,$GSD_FLAG,\"$REQ_VAL\",\"$ACT_VAL\"(Installed SSH version: $SSH_VER_COMPLETE),$RESULT" >> $REPORT
	fi
}

do_check_AV6015() {
	GSDREF="AV.6.0.15"
	ACT_VAL="UNKNOWN"
	REQ_VAL="aes128-ctr aes192-ctr aes256-ctr or 3DES"
	RESULT="Pass"
	TAG="Ciphers"
	GSD_FLAG="B"
	GSD_DESC=`$CAT $DESC_DIR/$GSDREF`
	
	TAG_COUNT=`$GREP "^$TAG" $SSH_CONFIG | $GREP "^$TAG " | $WC -l`
	if [ $TAG_COUNT -eq 1 ]
		then
		ACT_VAL=`$GREP "^$TAG" $SSH_CONFIG | $GREP "^$TAG " | $AWK '{print $2}'`
		for CIPHER in `echo $ACT_VAL | tr ',' '\n' |  sort | tr '\n' ','`
		do
			if [ `$ECHO $REQ_VAL | $GREP "$ACT_VAL1" | $WC -l` -eq 0 ]; then
				RESULT="Fail"
			fi
		done
		if [ "$RESULT" = "Fail" ]; then
				ECM_RESULT_FIELD="KO"
				ECM_SEVERITY_FIELD="Critical"
				print "\"${ECM_VERSION_FIELD}\",\"${ECM_SOURCE_FIELD}\",\"${ECM_CUSTOMER_ID_FIELD}\",\"${ECM_CUSTOMER_NAME_FIELD}\",\"${ECM_COUNTRY_FIELD}\",\"${ECM_HOSTNAME_FIELD}\",\"${ECM_IP_FIELD}\",\"${ECM_OS_NAME_FIELD}\",\"${ECM_OS_VERSION_FIELD}\",\"${ECM_SCAN_TYPE_FIELD}\",\"${ECM_APPLICATION_CATEGORY_FIELD}\",\"${ECM_APPLICATION_NAME_FIELD}\",\"${ECM_INSTANCE_NAME_FIELD}\",\"${ECM_DATE_STAMP}\",\"${ECM_POLICY_NAME_FIELD}\",\"${ECM_POLICY_VERSION_FIELD}\",\"${ECM_POLICY_ITEM_FIELD}\",\"${ECM_RESULT_FIELD}\",\"${ECM_SEVERITY_FIELD}\",\"${GSDREF}\",\"${GSD_DESC}\",\"${REQ_VAL}\",\"${ACT_VAL}\",\"${ECM_SUBMITTER_FIELD}\",\"${ECM_PERFORMER_FIELD}\",\"${ECM_EXTERNAL_REF_FIELD}\",\"${ECM_EXTERNAL_SEQ_FIELD}\"" >> "${ECM_OUTPUT_FILE}"
			fi
	else
		ACT_VAL="Parameter does not exists"	 
		RESULT="Fail"
		ECM_RESULT_FIELD="KO"
		ECM_SEVERITY_FIELD="Critical"
		print "\"${ECM_VERSION_FIELD}\",\"${ECM_SOURCE_FIELD}\",\"${ECM_CUSTOMER_ID_FIELD}\",\"${ECM_CUSTOMER_NAME_FIELD}\",\"${ECM_COUNTRY_FIELD}\",\"${ECM_HOSTNAME_FIELD}\",\"${ECM_IP_FIELD}\",\"${ECM_OS_NAME_FIELD}\",\"${ECM_OS_VERSION_FIELD}\",\"${ECM_SCAN_TYPE_FIELD}\",\"${ECM_APPLICATION_CATEGORY_FIELD}\",\"${ECM_APPLICATION_NAME_FIELD}\",\"${ECM_INSTANCE_NAME_FIELD}\",\"${ECM_DATE_STAMP}\",\"${ECM_POLICY_NAME_FIELD}\",\"${ECM_POLICY_VERSION_FIELD}\",\"${ECM_POLICY_ITEM_FIELD}\",\"${ECM_RESULT_FIELD}\",\"${ECM_SEVERITY_FIELD}\",\"${GSDREF}\",\"${GSD_DESC}\",\"${REQ_VAL}\",\"${ACT_VAL}\",\"${ECM_SUBMITTER_FIELD}\",\"${ECM_PERFORMER_FIELD}\",\"${ECM_EXTERNAL_REF_FIELD}\",\"${ECM_EXTERNAL_SEQ_FIELD}\"" >> "${ECM_OUTPUT_FILE}"
	fi
	print "$HOSTNAME,$GSD_DESC,$GSDREF,$GSD_FLAG,\"$REQ_VAL\",\"$ACT_VAL\"(Installed SSH version: $SSH_VER_COMPLETE),$RESULT" >> $REPORT
}

sun_ssh() {

	# gsdref_secription file format
	# GSDREF:System Value/Parameter:GSD_FLAG:VanDyke:openSSH:Sun_SSH:F-secure/RSIT:SSH Communications
	# AV.1.1.1:PermitEmptyPasswords:S:0:1:1:1:1
	while read gsdref_line
	do
		if [ "$ECM_OS_NAME_FIELD" = "Linux" ]; then
			$ECHO -n "."
		else
			$ECHO ".\c"
		fi
		GSD_FLAG=`$ECHO $gsdref_line | $AWK -F: '{print $3}'`
		CHECK=0
		if [ "$GSD_FLAG" = "B" ]; then
			if [ "$TYPE" = "B" ]; then
				CHECK=1
			fi
		else 
			if [ "$GSD_FLAG" = "S" ]; then
				CHECK=1
			fi
		fi
		
		if [ "$CHECK" = "1" ]; then
			PROTO=`$ECHO $gsdref_line | $AWK -F: '{ print $6 }'`
			GSDREF=`$ECHO $gsdref_line | $AWK -F: '{print $1}'`
			REQ_VAL=`$GREP ${GSDREF}: $GSD_REQ_VAL | $AWK -F: '{print $3}'`
			if [ "$GSDREF" = "AV.6.2.0" ] || [ "$GSDREF" = "AV.6.2.1" ] || [ "$GSDREF" = "AV.6.2.2" ] || [ "$GSDREF" = "AV.6.2.4" ] ; then
				#echo $GSDREF
				if [ "$PCI" = "0" ]; then
					RESULT="Pass"
					ACT_VAL="PCI Class requirement - Not Applicable"
					GSD_DESC=`$CAT $DESC_DIR/$GSDREF`
					print "$HOSTNAME,$GSD_DESC,$GSDREF,$GSD_FLAG,$REQ_VAL,$ACT_VAL,$RESULT" >> $REPORT
					continue;
				fi
			fi
			
			# $ECHO "Proto $PROTO"
			if [ ${#PROTO} -eq 1 ]; then 
				if [ $PROTO -eq 1 ]; then
					OPS=`$GREP ${GSDREF}: $GSD_REQ_VAL | $AWK -F: '{print $4}'`
					#$ECHO $OPS $GSDREF
					if [ "$OPS" = "eq" ]; then
						do_eq_check $GSDREF
					elif [ "$OPS" = "le" ]; then
						do_le_check $GSDREF
					elif [ "$OPS" = "ge" ]; then
						do_ge_check $GSDREF
					else
						NOT_VAL=`$ECHO $OPS | $AWK -F'!' '{print $2}'`
						OPS=`$ECHO $OPS | $AWK -F'&' '{print $1}'`
						if [ "$OPS" = "le" ]; then
							do_le_not_check $GSDREF $NOT_VAL
						fi
					fi
				elif [ $PROTO -eq 0 ]; then
					ACT_VAL="N/A"
					RESULT="Pass"
					REQ_VAL=`$GREP ${GSDREF}: $GSD_REQ_VAL | $AWK -F: '{print $3}'`
				fi
			else
				do_version_spec_chk $GSDREF $PROTO
			fi
			
			#   print "$HOSTNAME,$DESCRIPT,$GSDREF,$REQ_VAL,$ACT_VAL,$RESULT" >> $REPORT
			GSD_DESC=`$CAT $DESC_DIR/$GSDREF`
			
			# AV.1.4.5 - If parameter doesn't case for Solaris
			if [ "$GSDREF" = "AV.1.4.5" ] && [ "$ECM_OS_NAME_FIELD" = "SunOS" ]; then
				if [ "$ACT_VAL" = "Parameter does not exists" ];  then
					ECM_RESULT_FIELD="OK"
					ECM_SEVERITY_FIELD="Critical"
					RESULT="Pass"
				fi
			fi
			
			if [ "$RESULT" = "Fail" ]; then
				ECM_RESULT_FIELD="KO"
				ECM_SEVERITY_FIELD="Critical"
				print "\"${ECM_VERSION_FIELD}\",\"${ECM_SOURCE_FIELD}\",\"${ECM_CUSTOMER_ID_FIELD}\",\"${ECM_CUSTOMER_NAME_FIELD}\",\"${ECM_COUNTRY_FIELD}\",\"${ECM_HOSTNAME_FIELD}\",\"${ECM_IP_FIELD}\",\"${ECM_OS_NAME_FIELD}\",\"${ECM_OS_VERSION_FIELD}\",\"${ECM_SCAN_TYPE_FIELD}\",\"${ECM_APPLICATION_CATEGORY_FIELD}\",\"${ECM_APPLICATION_NAME_FIELD}\",\"${ECM_INSTANCE_NAME_FIELD}\",\"${ECM_DATE_STAMP}\",\"${ECM_POLICY_NAME_FIELD}\",\"${ECM_POLICY_VERSION_FIELD}\",\"${ECM_POLICY_ITEM_FIELD}\",\"${ECM_RESULT_FIELD}\",\"${ECM_SEVERITY_FIELD}\",\"${GSDREF}\",\"${GSD_DESC}\",\"${REQ_VAL}\",\"${ACT_VAL}\",\"${ECM_SUBMITTER_FIELD}\",\"${ECM_PERFORMER_FIELD}\",\"${ECM_EXTERNAL_REF_FIELD}\",\"${ECM_EXTERNAL_SEQ_FIELD}\"" >> "${ECM_OUTPUT_FILE}"
			fi
			print "$HOSTNAME,$GSD_DESC,$GSDREF,$GSD_FLAG,$REQ_VAL,$ACT_VAL(Installed SSH version: $SSH_VER_COMPLETE),$RESULT" >> $REPORT
		fi
	done<$GSDREF_DECR
	
	## AV.1.2.1.2 & V.1.2.1.3
	do_check_AV1212	
	do_check_AV1213
	
	## AV.2.1.1.1 & AV.5.0.1
	if [ "$TYPE" = "B" ]; then
		do_check_AV2111
		do_check_AV2113
		do_check_AV501
		do_check_AV1732_AV1733
	fi
	
	## AV.6.2.3
	do_check_AV623
	
}

open_ssh() {

	if [ -f "/etc/SuSE-release" ]; then
		OS_VER=`$HEAD -1 /etc/SuSE-release | $CUT -f5 -d' '`
		OS="SuSE${OS_VER}"
	elif [ -f "/etc/redhat-release" ]; then
		OS_VER=`$CAT /etc/redhat-release | $AWK -F' ' '{ print $7 }' | $AWK -F'.' '{ print $1 }'`
		OS="RedHat${OS_VER}"
	fi

	while read gsdref_line
	do
		if [ "$ECM_OS_NAME_FIELD" = "Linux" ]; then
			$ECHO -n "."
		else
			$ECHO ".\c"
		fi
		GSD_FLAG=`$ECHO $gsdref_line | $AWK -F: '{print $3}'`
		CHECK=0
		if [ "$GSD_FLAG" = "B" ]; then
			if [ "$TYPE" = "B" ]; then
				CHECK=1
			fi
		else 
			if [ "$GSD_FLAG" = "S" ]; then
				CHECK=1
			fi
		fi
		
		if [ "$CHECK" = "1" ]; then
			PROTO=`$ECHO $gsdref_line | $AWK -F: '{ print $5 }'`
			GSDREF=`$ECHO $gsdref_line | $AWK -F: '{print $1}'`
			
			
			if [ "$GSDREF" = "AV.6.2.1" ] || [ "$GSDREF" = "AV.6.2.2" ] || [ "$GSDREF" = "AV.6.2.3" ] || [ "$GSDREF" = "AV.6.2.4" ]; then
				if [ "$PCI" = "0" ]; then
					RESULT="Pass"
					ACT_VAL="PCI Class requirement - Not Applicable"
					GSD_DESC=`$CAT $DESC_DIR/$GSDREF`
					print "$HOSTNAME,$GSD_DESC,$GSDREF,$GSD_FLAG,$REQ_VAL,$ACT_VAL,$RESULT" >> $REPORT
					continue;
				fi
			fi
			
			if [ "$GSDREF" = "AV.6.0.8" ] || [ "$GSDREF" = "AV.6.0.12" ] || [ "$GSDREF" = "AV.6.0.13" ] || [ "$GSDREF" = "AV.6.0.14" ] || [ "$GSDREF" = "AV.6.0.16" ] || [ "$GSDREF" = "AV.6.0.17" ]; then
				if [ "$ECM_OS_NAME_FIELD" = "Linux" ]; then
					if [ "$OS" != "SuSE11" ]  && [ "$OS" != "RedHat6" ]; then
						RESULT="Pass"
						ACT_VAL="Not Applicable"
						if [ "$GSDREF" = "AV.6.0.8" ]; then
							GSD_DESC=`$CAT $DESC_DIR/${GSDREF}-Linux`
						else
							GSD_DESC=`$CAT $DESC_DIR/${GSDREF}`
						fi
						print "$HOSTNAME,$GSD_DESC,$GSDREF,$GSD_FLAG,$REQ_VAL,$ACT_VAL,$RESULT" >> $REPORT
						continue;
					fi
				fi
			fi

		
			if [ ${#PROTO} -eq 1 ]; then 
				if [ $PROTO -eq 1 ]; then
					OPS=`$GREP ${GSDREF}: $GSD_REQ_VAL | $AWK -F: '{print $4}'`
					#$ECHO $OPS $GSDREF
					if [ "$OPS" = "eq" ]; then
						do_eq_check $GSDREF
					elif [ "$OPS" = "le" ]; then
						do_le_check $GSDREF
					elif [ "$OPS" = "ge" ]; then
						do_ge_check $GSDREF
					else
						NOT_VAL=`$ECHO $OPS | $AWK -F'!' '{print $2}'`
						OPS=`$ECHO $OPS | $AWK -F'&' '{print $1}'`
						if [ "$OPS" = "le" ]; then
							do_le_not_check $GSDREF $NOT_VAL
						fi
					fi
				elif [ $PROTO -eq 0 ]; then
					ACT_VAL="N/A"
					RESULT="Pass"
					REQ_VAL=`$GREP ${GSDREF}: $GSD_REQ_VAL | $AWK -F: '{print $3}'`
				fi
			else
				do_version_spec_chk $GSDREF $PROTO
			fi

			#   print "$HOSTNAME,$DESCRIPT,$GSDREF,$REQ_VAL,$ACT_VAL,$RESULT" >> $REPORT
			if [ "$GSDREF" = "AV.6.0.1" ] || [ "$GSDREF" = "AV.6.0.3" ] || [ "$GSDREF" = "AV.6.0.4" ] || [ "$GSDREF" = "AV.6.0.6" ] || [ "$GSDREF" = "AV.6.0.8" ] || [ "$GSDREF" = "AV.6.0.13" ]; then
				if [ "$ECM_OS_NAME_FIELD" = "Linux" ]; then
					GSD_DESC=`$CAT $DESC_DIR/${GSDREF}-Linux`
				elif [ "$ECM_OS_NAME_FIELD" = "HP-UX" ]; then
					GSD_DESC=`$CAT $DESC_DIR/${GSDREF}-HP-UX`
				else
					GSD_DESC=`$CAT $DESC_DIR/${GSDREF}` 
				fi
			else
					GSD_DESC=`$CAT $DESC_DIR/${GSDREF}` 
			fi
			
			# AV.1.4.3 and AV.1.4.5 - If parameter doesn't case for Solaris
			if [ "$GSDREF" = "AV.1.4.2" ] || [ "$GSDREF" = "AV.1.4.3" ] || [ "$GSDREF" = "AV.1.4.5" ] ; then
				if [ "$ACT_VAL" = "Parameter does not exists" ];  then
					if [ "$ECM_OS_NAME_FIELD" = "SunOS" ]; then
						ECM_RESULT_FIELD="OK"
						ECM_SEVERITY_FIELD="Critical"
						RESULT="Pass"
					fi
				fi
			fi
			
			if [ "$RESULT" = "Fail" ]; then
				ECM_RESULT_FIELD="KO"
				ECM_SEVERITY_FIELD="Critical" 
				print "\"${ECM_VERSION_FIELD}\",\"${ECM_SOURCE_FIELD}\",\"${ECM_CUSTOMER_ID_FIELD}\",\"${ECM_CUSTOMER_NAME_FIELD}\",\"${ECM_COUNTRY_FIELD}\",\"${ECM_HOSTNAME_FIELD}\",\"${ECM_IP_FIELD}\",\"${ECM_OS_NAME_FIELD}\",\"${ECM_OS_VERSION_FIELD}\",\"${ECM_SCAN_TYPE_FIELD}\",\"${ECM_APPLICATION_CATEGORY_FIELD}\",\"${ECM_APPLICATION_NAME_FIELD}\",\"${ECM_INSTANCE_NAME_FIELD}\",\"${ECM_DATE_STAMP}\",\"${ECM_POLICY_NAME_FIELD}\",\"${ECM_POLICY_VERSION_FIELD}\",\"${ECM_POLICY_ITEM_FIELD}\",\"${ECM_RESULT_FIELD}\",\"${ECM_SEVERITY_FIELD}\",\"${GSDREF}\",\"${GSD_DESC}\",\"${REQ_VAL}\",\"${ACT_VAL}\",\"${ECM_SUBMITTER_FIELD}\",\"${ECM_PERFORMER_FIELD}\",\"${ECM_EXTERNAL_REF_FIELD}\",\"${ECM_EXTERNAL_SEQ_FIELD}\"" >> "${ECM_OUTPUT_FILE}"
			fi
			print "$HOSTNAME,$GSD_DESC,$GSDREF,$GSD_FLAG,$REQ_VAL,$ACT_VAL(Installed SSH version: $SSH_VER_COMPLETE),$RESULT" >> $REPORT
		fi
	done<$GSDREF_DECR
	
	## AV.1.2.1.2 & V.1.2.1.3
	do_check_AV1212
	do_check_AV1213
	
	## AV.2.1.1.1 & AV.5.0.1
	if [ "$TYPE" = "B" ]; then
		do_check_AV2111
		do_check_AV2113
		do_check_AV501
		do_check_AV1732_AV1733
	fi
	
	if [ "$ECM_OS_NAME_FIELD" = "Linux" ]; then
		do_check_AV6014
		if [ "$TYPE" = "B" ]; then
			do_check_AV6015
		fi
	fi
	if  [ "$ECM_OS_NAME_FIELD" = "SunOS" ]; then
		## AV.6.23
		do_check_AV623
	fi
	
	if [ "$ECM_OS_NAME_FIELD" = "HP-UX" ]; then
		do_check_AV602
	fi
}
####################
#    Main	   #
####################
PCI="0"
ECM_SUBMITTER_FIELD=""
ECM_PERFORMER_FIELD=""
ECM_EXTERNAL_REF_FIELD=""
ECM_EXTERNAL_SEQ_FIELD=""
TYPE="S"
while :
do
  case $1 in
	-type)
        if [ "$2" = "build" ]; then
			TYPE="B"
        #else
		#	TYPE="S"
		fi
		shift
        shift
		;;
	-pci)
		PCI="1"
        shift
        ;;
	-submitter)
		if [ `$ECHO $2 | grep '^-.*' | wc -l` -ne 0 ]; then
            $ECHO "Error: -submitter requires values"
            exit 1
        fi
		ECM_SUBMITTER_FIELD="$2"
		shift
		shift
		;;
	-performer) 
		if [ `$ECHO $2 | grep '^-.*' | wc -l` -ne 0 ]; then
            $ECHO "Error: -performer requires values"
            exit 1
        fi
		ECM_PERFORMER_FIELD="$2"
		shift
		shift
		;;
	-reference)
		if [ `$ECHO $2 | grep '^-.*' | wc -l` -ne 0 ]; then
            $ECHO "Error: -reference requires values"
            exit 1
        fi
		ECM_EXTERNAL_REF_FIELD="$2"
		shift
		shift
		;;
	-sequence)
		if [ `$ECHO $2 | grep '^-.*' | wc -l` -ne 0 ]; then
            $ECHO "Error: -sequence requires values"
            exit 1
        fi
		ECM_EXTERNAL_SEQ_FIELD="$2"
		shift
		shift
		;;
	-h | --help)
        $ECHO "Usage: $0 -type <build/operate> [-pci] [-submitter  <val>] [-performer <val>] [-reference <val>] [-sequence <val>]"
        exit 0
        ;;
	--) # End of all options
        shift
        break
       ;;
	-*)
        printf >&2 'WARN: Unknown option (ignored): %s\n' "$1"
        shift
        ;;
	*)  # no more options. Stop while loop
        break
		;;
  esac
done

if [ -z $TYPE ]; then
        $ECHO "Error: -type build|operate must pass to script"
        exit 1
fi

#if [ -z $ECM_SUBMITTER_FIELD ] && [ -z $ECM_PERFORMER_FIELD ] && [ -z $ECM_EXTERNAL_REF_FIELD ] && [ -z $ECM_EXTERNAL_SEQ_FIELD ]; then
#	$ECHO "Error: Either -submitter, -performer, -reference or -sequence missing"
#	exit 1
#fi

if [ -s "/etc/ssh/sshd_config" ]
then
	SSH_CONFIG="/etc/ssh/sshd_config"
elif [ -s "/opt/ssh/etc/sshd_config" ]
then
	SSH_CONFIG="/opt/ssh/etc/sshd_config"
elif [ -s "/opt/openssh/etc/sshd_config" ]
then
	SSH_CONFIG="/opt/openssh/etc/sshd_config"
elif [ -s "/usr/local/etc/sshd_config" ]
then
	SSH_CONFIG="/usr/local/etc/sshd_config"
else
	print "sshd_config file not found... couldn't continue the audit"
	exit 1
fi

print "Started running SSH Audit on $HOSTNAME ................" > $LOG_FILE
print "DATE: $DATE  ................" >> $LOG_FILE

Check_ssh_version
# Additional check for exact config file
if [ "$ECM_OS_NAME_FIELD" = "SunOS" ]; then
	if [ `ps -ef | grep '/usr/lib/ssh/sshd' | grep -v 'grep' | head -1 | wc -l` -eq  1 ]; then
		SSH_CONFIG="/etc/ssh/sshd_config"
		PKGTYPE="Sun_SSH"
	elif [ `ps -ef | grep '/usr/local/sbin/sshd' | grep -v 'grep' | head -1 | wc -l` -eq  1 ]; then
		SSH_CONFIG="/usr/local/etc/sshd_config"
		PKGTYPE="OpenSSH"
	fi
fi

#$ECHO $PKGTYPE $SSH_CONFIG

$ECHO "HOSTNAME,CATEGORY,SECTION,FLAG,EXPECTED_VALUE,CURRENT_VALUE(Installed SSH version: $SSH_VER_COMPLETE),POSTURE" > $REPORT
$ECHO "ECM_VERSION_FIELD,ECM_SOURCE_FIELD,ECM_CUSTOMER_ID_FIELD,ECM_CUSTOMER_NAME_FIELD,ECM_COUNTRY_FIELD,ECM_HOSTNAME_FIELD,ECM_IP_FIELD,ECM_OS_NAME_FIELD,ECM_OS_VERSION_FIELD,ECM_SCAN_TYPE_FIELD,ECM_APPLICATION_CATEGORY_FIELD,ECM_APPLICATION_NAME_FIELD,ECM_INSTANCE_NAME_FIELD,ECM_DATE_STAMP,ECM_POLICY_NAME_FIELD,ECM_POLICY_VERSION_FIELD,ECM_POLICY_ITEM_FIELD,ECM_RESULT_FIELD,ECM_SEVERITY_FIELD,ECM_CHECK_NAME_FIELD,ECM_CHECK_DESCRIPTION_FIELD,ECM_AGREED_SETTING_FIELD,ECM_REASON_FIELD,ECM_SUBMITTER_FIELD,ECM_PERFORMER_FIELD,ECM_EXTERNAL_REF_FIELD,ECM_EXTERNAL_SEQ_FIELD" > $ECM_OUTPUT_FILE
if [ "$ECM_OS_NAME_FIELD" = "Linux" ]; then
	$ECHO -n "["
else
	$ECHO "[\c"
fi

case $PKGTYPE in
	Sun_SSH) sun_ssh
		;;
	OpenSSH) 
			open_ssh
		;;
esac

# OSR's check
# osr_config file format
# Enabled/Disabled GSD_FLAG GSDREF OSR
# Ex: 1 S AV.1.8.2.1 /bin/openssl

while read CHECK GSD_FLAG GSDREF OSR
do
	if [ "$ECM_OS_NAME_FIELD" = "Linux" ]; then
		$ECHO -n "."
	else
		$ECHO ".\c"
	fi
	RESULT="Pass"
	REQ_VAL="If the file exists, it must be treated as an OSR"
	GSD_DESC=`$CAT $DESC_DIR/osr_default`
	if [ "$CHECK" = "1" ]; then
	  ACT_VAL="File does not exist"
	  if [ -f $OSR ] && [ ! -L $OSR ]
	  then
		#echo $OSR
		ACT_VAL=`ls -ld $OSR`
		RESULT=`ls -ld $OSR | grep -v "^l"| \
			awk '{if ($1!~/[d-][r-][w-][xsS-][r-][w-][xsS-][r-]-[xtT-]/ || $3!~/'$OSR_USRS'/ || $4!~/'$OSR_GRP'/) {
				 print "Fail";
				} else {
					print "Pass";
					}
			}'`
	  fi
	  if [ "$RESULT" = "Fail" ]; then
		ECM_RESULT_FIELD="KO"
		ECM_SEVERITY_FIELD="Critical"
		print "\"${ECM_VERSION_FIELD}\",\"${ECM_SOURCE_FIELD}\",\"${ECM_CUSTOMER_ID_FIELD}\",\"${ECM_CUSTOMER_NAME_FIELD}\",\"${ECM_COUNTRY_FIELD}\",\"${ECM_HOSTNAME_FIELD}\",\"${ECM_IP_FIELD}\",\"${ECM_OS_NAME_FIELD}\",\"${ECM_OS_VERSION_FIELD}\",\"${ECM_SCAN_TYPE_FIELD}\",\"${ECM_APPLICATION_CATEGORY_FIELD}\",\"${ECM_APPLICATION_NAME_FIELD}\",\"${ECM_INSTANCE_NAME_FIELD}\",\"${ECM_DATE_STAMP}\",\"${ECM_POLICY_NAME_FIELD}\",\"${ECM_POLICY_VERSION_FIELD}\",\"${ECM_POLICY_ITEM_FIELD}\",\"${ECM_RESULT_FIELD}\",\"${ECM_SEVERITY_FIELD}\",\"${GSDREF}\",\"${GSD_DESC}\",\"${REQ_VAL}\",\"${ACT_VAL}\",\"${ECM_SUBMITTER_FIELD}\",\"${ECM_PERFORMER_FIELD}\",\"${ECM_EXTERNAL_REF_FIELD}\",\"${ECM_EXTERNAL_SEQ_FIELD}\"" >> "${ECM_OUTPUT_FILE}"
	  fi
	  print "$HOSTNAME,$GSD_DESC,$GSDREF,$GSD_FLAG,\"$REQ_VAL\",$ACT_VAL(Installed SSH version: $SSH_VER_COMPLETE),$RESULT" >> $REPORT
	else
	  ACT_VAL="N/A"
	  print "$HOSTNAME,$GSD_DESC,$GSDREF,$GSD_FLAG,\"$REQ_VAL\",$ACT_VAL(Installed SSH version: $SSH_VER_COMPLETE),$RESULT" >> $REPORT
	fi
done<${OSR_CONF}
#echo $ECM_RESULT_FIELD
if [ "$ECM_RESULT_FIELD" = "OK" ]; then
	ECM_SEVERITY_FIELD="Information"
	GSD_DESC=""
	REQ_VAL=""
	ACT_VAL=""
	print "\"${ECM_VERSION_FIELD}\",\"${ECM_SOURCE_FIELD}\",\"${ECM_CUSTOMER_ID_FIELD}\",\"${ECM_CUSTOMER_NAME_FIELD}\",\"${ECM_COUNTRY_FIELD}\",\"${ECM_HOSTNAME_FIELD}\",\"${ECM_IP_FIELD}\",\"${ECM_OS_NAME_FIELD}\",\"${ECM_OS_VERSION_FIELD}\",\"${ECM_SCAN_TYPE_FIELD}\",\"${ECM_APPLICATION_CATEGORY_FIELD}\",\"${ECM_APPLICATION_NAME_FIELD}\",\"${ECM_INSTANCE_NAME_FIELD}\",\"${ECM_DATE_STAMP}\",\"${ECM_POLICY_NAME_FIELD}\",\"${ECM_POLICY_VERSION_FIELD}\",\"${ECM_POLICY_ITEM_FIELD}\",\"${ECM_RESULT_FIELD}\",\"${ECM_SEVERITY_FIELD}\",\"${GSDREF}\",\"${GSD_DESC}\",\"${REQ_VAL}\",\"${ACT_VAL}\",\"${ECM_SUBMITTER_FIELD}\",\"${ECM_PERFORMER_FIELD}\",\"${ECM_EXTERNAL_REF_FIELD}\",\"${ECM_EXTERNAL_SEQ_FIELD}\"" >> "${ECM_OUTPUT_FILE}"
fi
$ECHO "] Completed"
print "Audit completed on $HOSTNAME ................" >> $LOG_FILE
